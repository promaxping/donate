# Donate Site — Nguyễn Bảo Ngọc

This package contains two ready-to-deploy static sites for GitHub Pages.

## Structure
- `minimalist/` — simple dark page with QR
- `portfolio/`  — full profile with QR + social links
- `images/`     — shared images (avatar + qr)

## How to deploy on GitHub Pages
1. Create a **public** repo (e.g. `donate`) on your GitHub account.
2. Upload the content of **one version** (only `minimalist/` or `portfolio/`) into the root of the repo:
   - Open the folder, select all files inside it, and upload them to the repo root.
3. In the repo, go to **Settings → Pages**.
4. Under **Build and deployment**, set:
   - Source: `Deploy from a branch`
   - Branch: `main` and Folder: `/ (root)`
5. Save. Your site will be available at:
   `https://<your-username>.github.io/<repo>/`

### Replace images (optional)
- Replace `images/avatar.jpg` with your own portrait (square preferred).
- Replace `images/qr_tpbank.png` with a fresh QR if needed.

Enjoy! ☕